def _multiply_tuple(tuple):
    res = 1
    for x in tuple:
        res = res * x
    return res